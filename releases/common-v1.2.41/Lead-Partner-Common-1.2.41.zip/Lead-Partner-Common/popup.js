(() => {
  'use strict';
  const status=document.getElementById('shared-source-status'),form=document.getElementById('shared-source-config'),input=document.getElementById('shared-source-url'),save=document.getElementById('shared-source-save'),refresh=document.getElementById('shared-source-refresh');
  let configured=false,busy=false;
  async function render(){await LeadPartnerSourceCatalog.ready();const sources=LeadPartnerSourceCatalog.entries;document.getElementById('source-count').textContent=String(sources.length);const list=document.getElementById('source-list');list.replaceChildren();for(const source of sources){const item=document.createElement('li'),link=document.createElement('a'),url=document.createElement('small');link.textContent=source.code;link.href=source.url;link.target='_blank';link.rel='noopener noreferrer';url.textContent=source.url;item.append(link,url);list.append(item);}}
  function controls(){input.disabled=busy;save.disabled=busy;refresh.disabled=busy||!configured;form.setAttribute('aria-busy',String(busy));}
  function paint(result,loadUrl=false){
    if(typeof result?.configured==='boolean')configured=result.configured;
    if(loadUrl&&result?.url)input.value=result.url;
    if(!result?.ok){status.dataset.state='error';status.textContent=result?.error||result?.status?.error||'Проверка не выполнена. Используется последний исправный или встроенный каталог.';}
    else if(!configured){status.dataset.state='unconfigured';status.textContent='Общий каталог не подключён. Встроенные источники доступны.';}
    else if(result.status?.ok){status.dataset.state='ready';status.textContent='Каталог проверен · версия '+result.status.revision+' · '+new Date(result.status.checkedAt).toLocaleString('ru-RU');}
    else{status.dataset.state=result.status?'error':'unverified';status.textContent=result.status?.error||'Ссылка сохранена. Каталог ещё не проверен.';}
    controls();
  }
  async function run(command,url){
    if(busy)return;busy=true;controls();status.dataset.state='pending';status.textContent='Проверяем общий каталог…';
    try{const result=await chrome.runtime.sendMessage({type:'LP_SHARED_SOURCES',command,...(url===undefined?{}:{url})});paint(result);await render();}
    catch(_){paint({ok:false,error:'Не удалось проверить каталог. Используется последний исправный или встроенный каталог.'});}
    finally{busy=false;controls();}
  }
  form.addEventListener('submit',event=>{event.preventDefault();void run('configure',input.value.trim());});refresh.addEventListener('click',()=>void run('sync'));
  void render();LeadPartnerSourceCatalog.subscribe(()=>void render());
  if(globalThis.chrome?.runtime?.sendMessage){busy=true;controls();void chrome.runtime.sendMessage({type:'LP_SHARED_SOURCES',command:'status'}).then(result=>paint(result,true)).catch(()=>paint({ok:false,error:'Настройка каталога временно недоступна. Встроенные источники доступны.'})).finally(()=>{busy=false;controls();});}
  else paint({ok:false,error:'Настройка каталога недоступна.'});
})();

/* Employee connection diagnostics. */
(() => {
  'use strict';
  const unsupported='Проверка недоступна. Обновите расширение.';
  const reasons={
    '':'',deadline:'Сервер не ответил вовремя.',network:'Нет доступа к серверу. Проверьте интернет.',
    http:'Сервер вернул ошибку.',redirect:'Ответ пришёл с неподтверждённого адреса.',response:'Сервер вернул неожиданный ответ.',
    storage:'Не удалось прочитать данные расширения.',rate_limited:'Проверку можно повторять раз в 30 секунд.',
    identity_rejected:'Сервис отклонил подключение этой установки.',service_busy:'Сервис занят. Повторите проверку позже.',
    capacity:'Достигнут лимит подключений.',service:'Сервис временно недоступен.'
  };
  const version=value=>typeof value==='string'&&/^\d{1,5}(?:\.\d{1,5}){0,3}$/.test(value)&&value.split('.').every(part=>Number(part)<=65535);
  const time=value=>Number.isSafeInteger(value)&&value>=0&&value<=4102444800000;
  function presentation(value,fallbackVersion='') {
    const empty={status:unsupported,reason:'',version:version(fallbackVersion)?fallbackVersion:'—',installation:'Ещё не создана',lastSuccess:'Ещё не было'};
    if(!value||value.ok!==true||value.schema!==1||typeof value.configured!=='boolean'||!['ready','waiting','unavailable','storage_error','not_configured'].includes(value.state)
      ||!time(value.nextDueAt)||!time(value.lastSuccessAt)||!version(value.version)||!['admin','common'].includes(value.variant)
      ||typeof value.installation!=='string'||value.installation!==''&&!/^[a-f0-9]{8}$/i.test(value.installation)
      ||value.reason!==undefined&&(typeof value.reason!=='string'||!Object.prototype.hasOwnProperty.call(reasons,value.reason))
      ||value.httpStatus!==undefined&&(!Number.isInteger(value.httpStatus)||value.httpStatus<100||value.httpStatus>599)
      ||value.state==='ready'&&(!value.configured||!value.lastSuccessAt)||value.state==='waiting'&&!value.configured)return empty;
    const labels={ready:'Последний отчёт принят сервером.',waiting:'Отчёт ещё не отправлен.',unavailable:'Последняя проверка не удалась.',storage_error:'Не удалось прочитать данные расширения.',not_configured:'Подключение не настроено.'};
    return {status:labels[value.state],reason:value.reason==='http'&&value.httpStatus?'Сервер вернул ошибку HTTP '+value.httpStatus+'.':reasons[value.reason||''],
      version:value.version,installation:value.installation||'Ещё не создана',lastSuccess:value.lastSuccessAt?new Date(value.lastSuccessAt).toLocaleString('ru-RU'):'Ещё не было'};
  }
  globalThis.LeadPartnerEmployeeDiagnostics=Object.freeze({presentation});
  function install(){
    const byId=id=>document.getElementById(id),details=byId('employee-connection'),button=byId('employee-connection-check');
    if(!details||!button)return;
    let loaded=false,busy=false;
    const ownVersion=globalThis.chrome?.runtime?.getManifest?.().version||'';
    byId('employee-connection-version').textContent=version(ownVersion)?ownVersion:'—';
    function paint(result){
      const view=presentation(result,ownVersion);
      for(const[field,id]of [['status','status'],['version','version'],['installation','installation'],['lastSuccess','success'],['reason','reason']])byId('employee-connection-'+id).textContent=view[field];
      byId('employee-connection-reason').hidden=!view.reason;
    }
    function request(command){
      return new Promise(resolve=>{
        let settled=false;
        const finish=value=>{if(!settled){settled=true;resolve(value);}};
        try{
          const pending=chrome.runtime.sendMessage({type:'LP_EMPLOYEES_DIAGNOSTICS',schema:1,command},value=>finish(chrome.runtime.lastError?null:value));
          pending?.then?.(finish,()=>finish(null));
        }catch(_){finish(null);}
      });
    }
    async function run(command){
      if(busy)return;
      busy=true;loaded=true;button.disabled=true;details.setAttribute('aria-busy','true');
      byId('employee-connection-status').textContent=command==='check'?'Проверяем подключение…':'Получаем состояние…';
      byId('employee-connection-reason').hidden=true;
      try{paint(await request(command));}catch(_){paint(null);}
      finally{busy=false;button.disabled=false;details.setAttribute('aria-busy','false');}
    }
    details.addEventListener('toggle',()=>{if(details.open&&!loaded)void run('status');});
    button.addEventListener('click',()=>void run('check'));
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',install,{once:true});else install();
})();
