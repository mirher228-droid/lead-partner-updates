/* Read-only public Yandex driving routes. Distances are never inferred from map geometry. */
(function(root,factory){'use strict';if(typeof module==='object'&&module.exports)module.exports=factory(require('./leadchat-map-search.js'),()=>require('./leadchat-crm-city-catalog.js'));else root.LeadChatMapRoute=factory(root.LeadChatMapSearch,()=>root.LeadChatCrmCityCatalog);})(globalThis,function(maps,getCatalog){
  'use strict';
  const PARSER_VERSION='yandex-widget-routerResponse-3-native-locality';
  const provenance=Object.freeze({provider:'yandex',source:'yandex-public-widget',mode:'auto',direction:'from-city',parserVersion:PARSER_VERSION});
  const point=value=>Array.isArray(value)&&value.length===2&&value.every(Number.isFinite)&&Math.abs(value[0])<=180&&Math.abs(value[1])<=90;
  const samePoint=(a,b)=>point(a)&&point(b)&&a.every((v,i)=>Math.abs(v-b[i])<=1e-8);
  const clean=value=>String(value??'').normalize('NFKC').replace(/[\u0000-\u001f\u007f\u200b-\u200f]/g,' ').replace(/[\p{Extended_Pictographic}\uFE0F\u200D]/gu,' ').replace(/\s+/g,' ').trim().slice(0,400);
  const labelKey=value=>clean(value).toLocaleLowerCase('ru').replace(/ё/g,'е');
  const unavailable=(reason,extra={})=>({ok:false,state:'unavailable',...provenance,reason,...extra});
  function classify(distanceMeters){return typeof distanceMeters==='number'&&Number.isFinite(distanceMeters)&&distanceMeters>=0?(distanceMeters<37000?'near':'far'):'unavailable';}
  function nativeDistanceLabel(value){
    // Parse only the selected response's own safe label. Keep its original
    // spacing and decimal separator for display; raw metres never round it.
    if(typeof value!=='string'||value.length>80)return null;
    const match=/^[ \u00a0\u202f]*((?:\d{1,3}(?:[ \u00a0\u202f]\d{3})+|\d+)(?:[.,]\d+)?)[ \u00a0\u202f]+(км|м)[ \u00a0\u202f]*$/iu.exec(value);
    if(!match)return null;
    const amount=Number(match[1].replace(/[ \u00a0\u202f]/g,'').replace(',','.'));
    const displayDistanceMeters=amount*(match[2].toLocaleLowerCase('ru')==='км'?1000:1);
    return Number.isFinite(displayDistanceMeters)&&displayDistanceMeters>=0&&displayDistanceMeters<=Number.MAX_SAFE_INTEGER?{distanceText:value,displayDistanceMeters}:null;
  }
  function mainBranch({base,city,cityId}={}){
    if(base!=='kp')return null;
    const list=getCatalog()?.kp;if(!Array.isArray(list))return null;
    const matches=list.filter(item=>labelKey(item.text)===labelKey(city)&&(!cityId||String(item.id)===String(cityId)));
    if(matches.length!==1)return null;
    const entry=matches[0],label=clean(entry.text);
    // A region tag is not a satellite parent. All other parenthetical routing
    // cities come directly from the CRM selector and exclude this branch.
    if([...label.matchAll(/\(([^)]*)\)/g)].some(match=>labelKey(match[1])!=='мск'))return null;
    const names=maps.geographicCityNames(label);
    if(names.length!==1||!names[0]||/^(?:test|тест|кц)$/iu.test(names[0]))return null;
    return {base,city:entry.text,cityId:String(entry.id),originName:names[0],branchType:'main',proofSource:'crm-city-catalog'};
  }
  function parseRoutePage(html,{origin,destination}={}){
    const endpoints=point(origin)&&point(destination)?{origin:origin.slice(),destination:destination.slice()}:{};
    const fail=reason=>unavailable(reason,endpoints);
    if(!point(origin)||!point(destination))return fail('invalid-points');
    if(typeof html!=='string'||html.length>6000000)return fail('invalid-response-size');
    if(/checkbox-captcha-form|id=["']js-button["']|\/showcaptcha\?/.test(html))return fail('yandex-verification-required');
    const scripts=[...html.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script>/gi)].filter(item=>/\bconfig-view\b/.test(item[1])&&/type\s*=\s*["']application\/json["']/i.test(item[1]));
    if(scripts.length!==1)return fail('route-data-unavailable');
    let config;try{config=JSON.parse(scripts[0][2]);}catch(_){return fail('invalid-route-json');}
    const rtext=[origin,destination].map(p=>p[1]+','+p[0]).join('~'),response=config?.routerResponse;
    if(config?.query?.mode!=='routes'||config.query.rtt!=='auto'||config.query.rtext!==rtext||response?.type!=='auto')return fail('unproven-route-mode-or-direction');
    if(!Array.isArray(config.routePoints)||config.routePoints.length!==2||!config.routePoints.every((p,i)=>samePoint(p?.coords,[origin,destination][i])))return fail('unproven-route-points');
    if(!Array.isArray(response.waypoints)||response.waypoints.length!==2||!response.waypoints.every((p,i)=>p?.index===i&&samePoint(p.request,[origin,destination][i])&&samePoint(p.coordinates,[origin,destination][i])))return fail('unproven-response-endpoints');
    if(!Array.isArray(response.viaIndexes)||response.viaIndexes.length||!Array.isArray(response.viaPoints)||response.viaPoints.length)return fail('unexpected-via-points');
    if(!Array.isArray(response.routes)||!response.routes.length||response.routes.length>20)return fail('no-driving-route');
    const alternatives=[];
    for(const route of response.routes){
      if(route?.type!=='auto'||route.flags?.blocked===true)continue;
      const distanceMeters=route.distance?.value;
      if(classify(distanceMeters)==='unavailable')return fail('invalid-route-distance');
      const label=nativeDistanceLabel(route.distance?.text);
      alternatives.push({distanceMeters,distanceText:label?.distanceText??null,displayDistanceMeters:label?.displayDistanceMeters??null,durationSeconds:typeof route.duration==='number'&&Number.isFinite(route.duration)&&route.duration>=0?route.duration:null,routeId:clean(route.uuid)});
    }
    if(!alternatives.length)return fail('no-driving-route');
    const selected=alternatives.reduce((shortest,route)=>route.distanceMeters<shortest.distanceMeters?route:shortest);
    if(selected.distanceText===null)return fail('unproven-route-distance-label');
    const {distanceMeters,distanceText,displayDistanceMeters}=selected;
    return {ok:true,state:'known',...provenance,...endpoints,distanceMeters,distanceText,displayDistanceMeters,classification:classify(displayDistanceMeters),alternatives,proof:{query:{mode:'routes',rtt:'auto',rtext},waypoints:response.waypoints.map(p=>({index:p.index,request:p.request.slice(),coordinates:p.coordinates.slice()})),selection:'minimum-distance-of-returned-driving-alternatives',selectedRouteId:selected.routeId,distanceLabelSource:'selected-route.distance.text'}};
  }
  const abortError=()=>new DOMException('Расчёт маршрута отменён','AbortError');
  function withSignal(promise,signal){
    return new Promise((resolve,reject)=>{
      if(signal?.aborted){Promise.resolve(promise).catch(()=>{});reject(abortError());return;}
      let done=false;
      const finish=(callback,value)=>{if(done)return;done=true;signal?.removeEventListener('abort',stop);callback(value);};
      const stop=()=>finish(reject,abortError());
      signal?.addEventListener('abort',stop,{once:true});
      Promise.resolve(promise).then(value=>finish(resolve,value),error=>finish(reject,error));
    });
  }
  function create(options={}){
    const request=options.fetch||globalThis.fetch,now=options.now||Date.now,mapSearch=options.mapSearch||maps.create({fetch:request,now}),cache=new Map(),inflight=new Map();
    const timeoutMs=Number.isFinite(options.timeoutMs)&&options.timeoutMs>0?Math.min(options.timeoutMs,18000):18000;
    async function route({base,city,cityId,destinationLocality,signal}={}){
      if(signal?.aborted)throw abortError();
      const branch=mainBranch({base,city,cityId});
      if(!branch)return unavailable('ineligible-branch');
      const localityKey=maps.addressLocalityKey(destinationLocality);
      if(!localityKey||typeof mapSearch.resolveLocality!=='function')return unavailable('unproven-address-locality');
      let cityResult,localityResult;
      const cityController=new AbortController(),stopCity=()=>cityController.abort(),cityTimer=setTimeout(stopCity,timeoutMs);
      signal?.addEventListener('abort',stopCity,{once:true});
      try{[cityResult,localityResult]=await withSignal(Promise.all([mapSearch.search({base,city:branch.city,cityOnly:true,signal:cityController.signal}),mapSearch.resolveLocality({base,locality:destinationLocality,signal:cityController.signal})]),cityController.signal);}catch(error){if(signal?.aborted)throw abortError();return unavailable(cityController.signal.aborted?'city-point-timeout':'city-or-locality-point-unavailable');}
      finally{clearTimeout(cityTimer);signal?.removeEventListener('abort',stopCity);}
      if(signal?.aborted)throw abortError();
      const cities=cityResult?.cityIdentities;
      if(!Array.isArray(cities)||cities.length!==1)return unavailable('unproven-city-point');
      const identity=cities[0];
      if(!/^\d{1,24}$/.test(String(identity.id||''))||!point(identity.coordinates)||maps.branchKey(identity.title)!==maps.branchKey(branch.originName)||labelKey(identity.country)!=='россия')return unavailable('unproven-city-point');
      const locality=localityResult?.identity;
      if(localityResult?.ok!==true||locality?.source!=='yandex-locality-point'||locality.addressIdentity!==localityKey||!/^\d{1,24}$/.test(String(locality.id||''))||!/^ymapsbm1:\/\/geo\?data=[A-Za-z0-9_,=-]{1,3900}$/.test(String(locality.uri||''))||!point(locality.coordinates)||labelKey(locality.country)!=='россия')return unavailable('unproven-destination-locality');
      destinationLocality=structuredClone(locality);
      const destination=locality.coordinates.slice();
      const origin=identity.coordinates.slice(),originCity={id:String(identity.id),title:clean(identity.title),coordinates:origin.slice(),country:clean(identity.country),regionId:clean(identity.regionId),uri:clean(identity.uri),source:'yandex-locality-point',catalogCityId:branch.cityId};
      const key=[PARSER_VERSION,'auto','from-city',base,branch.cityId,origin.join(','),destinationLocality.id,destinationLocality.uri,destinationLocality.regionId,destination.join(','),localityKey].join('|'),previous=cache.get(key);
      if(previous&&now()-previous.at<300000)return structuredClone(previous.result);
      let pending=inflight.get(key);
      if(!pending){
        const controller=new AbortController();pending={controller,users:0,promise:null};const current=pending;
        const timer=setTimeout(()=>controller.abort(),timeoutMs);
        pending.promise=Promise.resolve().then(async()=>{try{
          const url=new URL('https://yandex.ru/map-widget/v1/');
          for(const [name,value]of Object.entries({mode:'routes',rtext:[origin,destination].map(p=>p[1]+','+p[0]).join('~'),rtt:'auto',lang:'ru_RU'}))url.searchParams.set(name,value);
          const response=await withSignal(request(url.href,{credentials:'omit',cache:'no-store',signal:controller.signal,headers:{Accept:'text/html'}}),controller.signal),resolved=new URL(response.url||url.href);
          if(!response.ok||resolved.origin!==url.origin||resolved.pathname!==url.pathname)return unavailable('route-http-unavailable',{origin,destination,originCity});
          const html=await withSignal(response.text(),controller.signal);
          if(controller.signal.aborted)throw abortError();
          const parsed=parseRoutePage(html,{origin,destination}),result={...parsed,originCity,destinationLocality,requestUrl:url.href,checkedAt:now()};
          if(result.ok){cache.set(key,{at:now(),result:structuredClone(result)});while(cache.size>50)cache.delete(cache.keys().next().value);}
          return result;
        }catch(error){return unavailable(controller.signal.aborted?'route-timeout':'route-fetch-unavailable',{origin,destination,originCity});}
        finally{clearTimeout(timer);if(inflight.get(key)===current)inflight.delete(key);}});
        inflight.set(key,pending);
      }
      // Callers share only the public request. Each operator selection owns its
      // cancellation; the final departing caller cancels the underlying fetch.
      return new Promise((resolve,reject)=>{
        pending.users++;let settled=false;
        const finish=(callback,value)=>{if(settled)return;settled=true;signal?.removeEventListener('abort',stop);pending.users--;callback(value);};
        const stop=()=>{finish(reject,abortError());if(!pending.users){if(inflight.get(key)===pending)inflight.delete(key);pending.controller.abort();}};
        signal?.addEventListener('abort',stop,{once:true});
        pending.promise.then(value=>finish(resolve,structuredClone(value)),error=>finish(reject,error));
        if(signal?.aborted)stop();
      });
    }
    return Object.freeze({route});
  }
  return Object.freeze({PARSER_VERSION,classify,mainBranch,parseRoutePage,create});
});
