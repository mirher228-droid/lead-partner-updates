/* One background presence reporter. No CRM polling and no customer/chat data. */
(function (root, factory) {
  'use strict';
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else { root.LeadPartnerEmployeesClient = api; api.install(); }
})(globalThis, function (root) {
  'use strict';
  const DEVICE = 'leadPartnerEmployeesDeviceV1', STATE = 'leadPartnerEmployeesStateV1';
  const ALARM = 'leadPartnerEmployeesHeartbeatV1', PERIOD = 300000, MAX_BACKOFF = 3600000, DEADLINE = 15000;
  const installations = new WeakMap();
  const uuid = value => typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
  const token = value => typeof value === 'string' && /^[A-Za-z0-9_-]{43,86}$/.test(value);
  const operator = value => typeof value === 'string' && /^[A-Za-z0-9_-]{1,64}$/.test(value);
  const name = value => typeof value === 'string' && value.length > 0 && value.length <= 120 && value === value.trim() && !/[\x00-\x1f\x7f]/.test(value);
  function endpoint(value) {
    try {
      if (typeof value !== 'string' || value.length > 500) return '';
      const url = new URL(value);
      return url.protocol === 'https:' && url.hostname === 'script.google.com' && !url.port && !url.username && !url.password && !url.search && !url.hash
        && /^\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(url.pathname) ? url.href : '';
    } catch (_) { return ''; }
  }
  function safeResponseUrl(value, target) {
    try {
      const url = new URL(value || target);
      return !url.username && !url.password && !url.port && url.protocol === 'https:'
        && (url.href === target || url.hostname === 'script.googleusercontent.com' && url.pathname === '/macros/echo');
    } catch (_) { return false; }
  }
  function identityMessage(message, sender, extensionId) {
    if (!message || typeof message !== 'object' || message.type !== 'LP_EMPLOYEES_IDENTITY' || message.schema !== 1 || sender?.id !== extensionId) return null;
    try {
      const url = new URL(sender.url);
      if (url.username || url.password || url.port) return null;
      const fields=Object.keys(message).sort().join(',');
      const legacy=fields === 'operatorId,schema,source,type';
      const paired=fields === 'displayName,operatorId,schema,source,type' && (message.displayName === '' || name(message.displayName));
      if (message.source === 'leadchat-session' && (legacy || paired) && operator(message.operatorId)
        && ['https:','http:'].includes(url.protocol) && ['188-225-34-82.sslip.io','72-56-68-159.sslip.io','chat.partner-lead-centre.ru'].includes(url.hostname)
        && /^\/chats\/[A-Za-z0-9_-]{1,100}\/?$/.test(url.pathname)) return {operatorId:message.operatorId,displayName:paired ? message.displayName : '',identitySource:'leadchat-session'};
    } catch (_) { /* Never reply with private state to a page. */ }
    return null;
  }
  function create(environment = {}) {
    const chrome = environment.chrome || root.chrome;
    const storage = environment.storage || chrome?.storage?.local;
    const config = environment.config || root.LeadPartnerEmployeesConfig || {};
    const target = config.schema === 1 ? endpoint(config.url) : '';
    const now = environment.now || Date.now, random = environment.random || Math.random;
    const fetch = environment.fetch || root.fetch?.bind(root), crypto = environment.crypto || root.crypto;
    const setTimer = environment.setTimeout || root.setTimeout.bind(root), clearTimer = environment.clearTimeout || root.clearTimeout.bind(root);
    const version = String(chrome?.runtime?.getManifest?.().version || '').slice(0,32);
    const variant = config.variant === 'admin' ? 'admin' : 'common';
    let publicState = {configured:!!target,state:target ? 'waiting' : 'not_configured',nextDueAt:0,lastSuccessAt:0};
    let queue = Promise.resolve(), inFlight = null;
    const serialize = task => { const work = queue.catch(() => {}).then(task); queue = work; return work; };
    const getState = () => ({...publicState});
    function schedule(when) {
      try { const result = chrome?.alarms?.create(ALARM,{when:Math.max(now()+1000,when)}); result?.catch?.(() => {}); } catch (_) {}
    }
    function setState(state, stored) {
      publicState = {configured:!!target,state,nextDueAt:stored?.nextDueAt || 0,lastSuccessAt:stored?.lastSuccessAt || 0};
    }
    function freshDevice() {
      // Refuse to manufacture weak or replacement credentials when secure randomness is unavailable.
      if (typeof crypto?.getRandomValues !== 'function') throw Error('storage');
      const bytes=crypto.getRandomValues(new Uint8Array(32));
      const deviceToken=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
      const idBytes=crypto.getRandomValues(new Uint8Array(16)); idBytes[6]=(idBytes[6]&15)|64; idBytes[8]=(idBytes[8]&63)|128;
      const hex=Array.from(idBytes,b=>b.toString(16).padStart(2,'0')).join('');
      return {schema:1,installationId:[hex.slice(0,8),hex.slice(8,12),hex.slice(12,16),hex.slice(16,20),hex.slice(20)].join('-'),deviceToken};
    }
    async function read() {
      // A rejected/partial read is never interpreted as an empty installation.
      if (!storage?.get || !storage?.set) throw Error('storage');
      const all = await storage.get([DEVICE,STATE]);
      if (!all || typeof all !== 'object') throw Error('storage');
      const device=all[DEVICE], saved=all[STATE];
      if (device !== undefined && (!device || device.schema !== 1 || !uuid(device.installationId) || !token(device.deviceToken))) throw Error('storage');
      if (device === undefined && saved !== undefined) throw Error('storage');
      let state=saved === undefined ? {schema:1,serviceUrl:target,nextDueAt:0,lastSuccessAt:0,failures:0,operatorId:'',displayName:'',identitySource:''} : saved;
      if (!state || state.schema !== 1 || !Number.isFinite(state.nextDueAt) || state.nextDueAt < 0 || !Number.isFinite(state.lastSuccessAt) || state.lastSuccessAt < 0
        || !Number.isInteger(state.failures) || state.failures < 0 || state.failures > 6 || state.operatorId !== '' && !operator(state.operatorId) || state.displayName !== '' && !name(state.displayName)
        || state.identitySource !== undefined && !['','leadchat-session'].includes(state.identitySource)) throw Error('storage');
      // Old displayName values came from whichever CRM was loaded. Only the
      // authenticated LeadChat ID/name pair may supply a name after this update.
      state={...state,displayName:state.identitySource === 'leadchat-session' ? state.displayName : '',identitySource:state.identitySource === 'leadchat-session' ? 'leadchat-session' : ''};
      // Deployment state belongs to the configured service; the local device
      // credential remains unchanged when a deployment changes.
      if (state.serviceUrl !== target) state={...state,serviceUrl:target,nextDueAt:0,lastSuccessAt:0,failures:0};
      // A PC clock correction must never defer the reporter for days or years.
      if (state.nextDueAt > now()+MAX_BACKOFF+30000 || state.lastSuccessAt > now()+60000) state={...state,nextDueAt:0,lastSuccessAt:0};
      return {device,state};
    }
    function jitter() { return Math.floor(Math.max(0,Math.min(1,random())) * 30000); }
    async function post(body) {
      const controller=new AbortController(); let timer;
      const timeout=new Promise((_,reject)=>{timer=setTimer(()=>{controller.abort();reject(Error('deadline'));},DEADLINE);});
      try {
        const work=(async()=>{
          const response=await fetch(target,{method:'POST',credentials:'omit',cache:'no-store',redirect:'follow',referrerPolicy:'no-referrer',
            headers:{'Content-Type':'text/plain;charset=UTF-8'},body:JSON.stringify(body),signal:controller.signal});
          if (!response?.ok || !safeResponseUrl(response.url,target)) throw Error('unavailable');
          const text=await response.text();
          if (typeof text !== 'string' || text.length>2048) throw Error('unavailable');
          const reply=JSON.parse(text);
          if (reply?.ok !== true || reply.schema !== 1 || !Number.isFinite(reply.serverTime) || reply.serverTime <= 0 || reply.nextAfterMs !== PERIOD) throw Error('unavailable');
        })();
        await Promise.race([work,timeout]);
      } finally { clearTimer(timer); }
    }
    async function run() {
      if (!target) {setState('not_configured');return getState();}
      let records;
      try {
        records=await read();
        const {state}=records;
        if (state.nextDueAt>now()) {setState(state.failures ? 'unavailable' : state.lastSuccessAt ? 'ready' : 'waiting',state);schedule(state.nextDueAt);return getState();}
        const device=records.device || freshDevice();
        const reserved={...state,nextDueAt:now()+PERIOD+jitter()};
        await storage.set({...(records.device ? {} : {[DEVICE]:device}),[STATE]:reserved});
        records={device,state:reserved}; schedule(reserved.nextDueAt);
      } catch (_) {setState('storage_error');schedule(now()+PERIOD);return getState();}
      const {device,state}=records;
      let next;
      try {
        await post({schema:1,action:'heartbeat',installationId:device.installationId,deviceToken:device.deviceToken,
          operatorId:state.operatorId,displayName:state.displayName,version,variant});
        // Pace from the acknowledgement too: request latency must not make the
        // next heartbeat arrive before the server's own five-minute boundary.
        next={...state,failures:0,lastSuccessAt:now(),nextDueAt:now()+PERIOD+jitter()};
        await storage.set({[STATE]:next}); setState('ready',next);
      } catch (_) {
        const failures=Math.min(6,state.failures+1);
        next={...state,failures,nextDueAt:now()+Math.min(MAX_BACKOFF,PERIOD*2**(failures-1))+jitter()};
        try {await storage.set({[STATE]:next});setState('unavailable',next);}
        catch (_) {setState('storage_error',state);next=state;}
      }
      schedule(next.nextDueAt);return getState();
    }
    function tick() {
      if (inFlight) return inFlight;
      inFlight=serialize(run).finally(()=>{inFlight=null;});return inFlight;
    }
    function updateIdentity(update) {
      if (!target || !update) return undefined;
      return serialize(async()=>{
        try {
          const {device,state}=await read();
          const next={...state,...update};
          if (next.operatorId === state.operatorId && next.displayName === state.displayName && next.identitySource === state.identitySource) return true;
          await storage.set({...(device ? {} : {[DEVICE]:freshDevice()}),[STATE]:next});
          return true;
        } catch (_) { return false; /* A failed write must not acknowledge a captured identity. */ }
      });
    }
    function handleMessage(message,sender) {
      return updateIdentity(identityMessage(message,sender,chrome?.runtime?.id));
    }
    const client=Object.freeze({tick,handleMessage,getState});
    return client;
  }
  function install(environment = {}) {
    const chrome=environment.chrome || root.chrome;
    if (!chrome?.runtime?.onMessage || !chrome.storage?.local) return null;
    if (installations.has(chrome.runtime)) return installations.get(chrome.runtime);
    const client=create(environment); installations.set(chrome.runtime,client);
    chrome.runtime.onMessage.addListener((message,sender,reply)=>{
      const receipt=client.handleMessage(message,sender);
      if (!receipt) return;
      void receipt.then(ok=>reply({ok:ok===true})).catch(()=>{});
      return true;
    });
    chrome.alarms?.onAlarm?.addListener(alarm=>{if(alarm?.name===ALARM)void client.tick();});
    chrome.runtime.onStartup?.addListener(()=>{void client.tick();});
    chrome.runtime.onInstalled?.addListener(()=>{void client.tick();});
    void client.tick();
    return client;
  }
  function reportCrmSession(displayName) {
    // Keep the existing background API for older callers, without allowing a
    // CRM account to overwrite the current authenticated LeadChat account.
    return null;
  }
  return Object.freeze({create,install,reportCrmSession});
});
