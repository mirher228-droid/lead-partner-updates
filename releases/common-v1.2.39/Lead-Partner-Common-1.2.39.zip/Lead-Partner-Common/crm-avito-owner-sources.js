/* Exact source mappings supplied by the owner, 2026-10-22. IDs remain strings. */
(() => {
  'use strict';
  const entries = [
  {
    "code": "Б1",
    "url": "https://www.avito.ru/brands/komphelper",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "1933",
        "base": "kp"
      }
    ],
    "externalIds": [
      "1933"
    ]
  },
  {
    "code": "Б6",
    "url": "https://clck.ru/3Ustqt",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "3992",
        "base": "kp"
      }
    ],
    "externalIds": [
      "3992"
    ]
  },
  {
    "code": "Б7",
    "url": "https://clck.ru/3UtxEt",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "9485",
        "base": "kp"
      }
    ],
    "externalIds": [
      "9485"
    ]
  },
  {
    "code": "Б8",
    "url": "https://clck.ru/3VAhwk",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "8869",
        "base": "kp"
      }
    ],
    "externalIds": [
      "8869"
    ]
  },
  {
    "code": "Б9",
    "url": "https://clck.ru/3W7ZB9",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "2997",
        "base": "kp"
      }
    ],
    "externalIds": [
      "2997"
    ]
  },
  {
    "code": "Б10",
    "url": "https://clck.ru/3W7ZCn",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "6874",
        "base": "kp"
      }
    ],
    "externalIds": [
      "6874"
    ]
  },
  {
    "code": "Б11",
    "url": "https://clck.ru/3WNPgb",
    "partnerId": "723",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "3423",
        "base": "kp"
      }
    ],
    "externalIds": [
      "3423"
    ]
  },
  {
    "code": "Б12",
    "url": "https://clck.ru/3WVoo7",
    "partnerId": "723",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "4476",
        "base": "bt"
      }
    ],
    "externalIds": [
      "4476"
    ]
  },
  {
    "code": "А5",
    "url": "https://clck.ru/3T9WL7",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "0815",
        "base": "kp"
      }
    ],
    "externalIds": [
      "0815"
    ]
  },
  {
    "code": "С74",
    "url": "https://clc.li/LQWwl",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "8525",
        "base": "kp"
      }
    ],
    "externalIds": [
      "8525"
    ]
  },
  {
    "code": "С75",
    "url": "https://clc.li/ehPWa",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "0884",
        "base": "kp"
      }
    ],
    "externalIds": [
      "0884"
    ]
  },
  {
    "code": "С78",
    "url": "https://clck.ru/3UvY6f",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "6731",
        "base": "kp"
      }
    ],
    "externalIds": [
      "6731"
    ]
  },
  {
    "code": "С82",
    "url": "https://clck.ru/3TD2b2",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "6913",
        "base": "kp"
      }
    ],
    "externalIds": [
      "6913"
    ]
  },
  {
    "code": "С97",
    "url": "https://clck.ru/3W7ZHL",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "5284",
        "base": "kp"
      }
    ],
    "externalIds": [
      "5284"
    ]
  },
  {
    "code": "В81",
    "url": "https://clc.li/xkMiW",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "8952",
        "base": "kp"
      }
    ],
    "externalIds": [
      "8952"
    ]
  },
  {
    "code": "В83",
    "url": "https://golnk.ru/88OvG",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "6539",
        "base": "kp"
      }
    ],
    "externalIds": [
      "6539"
    ]
  },
  {
    "code": "В84.2",
    "url": "https://clck.ru/3SugR5",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "9723",
        "base": "kp"
      }
    ],
    "externalIds": [
      "9723"
    ]
  },
  {
    "code": "В89",
    "url": "https://clck.su/ziPTe",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "6398",
        "base": "kp"
      }
    ],
    "externalIds": [
      "6398"
    ]
  },
  {
    "code": "М2",
    "url": "https://clck.ru/3UvYB4",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "0480",
        "base": "kp"
      }
    ],
    "externalIds": [
      "0480"
    ]
  },
  {
    "code": "М12",
    "url": "https://clck.ru/3WRxTY",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "2287",
        "base": "kp"
      }
    ],
    "externalIds": [
      "2287"
    ]
  },
  {
    "code": "М13",
    "url": "https://clck.su/uQKRE",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "1467",
        "base": "kp"
      }
    ],
    "externalIds": [
      "1467"
    ]
  },
  {
    "code": "М16",
    "url": "https://clck.ru/3Vx2xR",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "7504",
        "base": "kp"
      }
    ],
    "externalIds": [
      "7504"
    ]
  },
  {
    "code": "М17",
    "url": "https://clck.ru/3WRxbn",
    "sourceBases": [
      "kp"
    ],
    "externalRefs": [
      {
        "id": "5375",
        "base": "kp"
      }
    ],
    "externalIds": [
      "5375"
    ]
  },
  {
    "code": "А4",
    "url": "https://clck.ru/3WJ6Mj",
    "sourceBases": [
      "bt",
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "8013",
        "base": ""
      }
    ],
    "externalIds": [
      "8013"
    ]
  },
  {
    "code": "С74.2",
    "url": "https://clc.li/PKngr",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "6012",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "6012"
    ]
  },
  {
    "code": "С76",
    "url": "https://clc.li/PiZKM",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "4364",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "4364"
    ]
  },
  {
    "code": "С77",
    "url": "https://clck.su/xsEvX",
    "sourceBases": [
      "bt",
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "3118",
        "base": ""
      }
    ],
    "externalIds": [
      "3118"
    ]
  },
  {
    "code": "С79.2",
    "url": "https://clck.su/WSkHf",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "6881",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "6881"
    ]
  },
  {
    "code": "С85",
    "url": "https://clck.su/iELSy",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "6608",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "6608"
    ]
  },
  {
    "code": "В43",
    "url": "https://clc.li/fDPJY",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "8267",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "8267"
    ]
  },
  {
    "code": "В71",
    "url": "https://clc.li/UFpwd",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "5613",
        "base": "bt"
      }
    ],
    "externalIds": [
      "5613"
    ]
  },
  {
    "code": "В75",
    "url": "https://clck.su/DPPJJ",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "5811",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "5811"
    ]
  },
  {
    "code": "В80",
    "url": "https://clck.ru/3WW7nm",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "2388",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "2388"
    ]
  },
  {
    "code": "В82",
    "url": "https://clck.ru/3SWmcy",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "2392",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "2392"
    ]
  },
  {
    "code": "В95",
    "url": "https://clc.li/OCzal",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "8774",
        "base": "bt"
      }
    ],
    "externalIds": [
      "8774"
    ]
  },
  {
    "code": "М5",
    "url": "https://clck.ru/3UvYNE",
    "sourceBases": [
      "mnc"
    ],
    "externalRefs": [
      {
        "id": "1095",
        "base": "mnc"
      }
    ],
    "externalIds": [
      "1095"
    ]
  },
  {
    "code": "М10",
    "url": "https://clck.ru/3VwpZP",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "3054",
        "base": "bt"
      }
    ],
    "externalIds": [
      "3054"
    ]
  },
  {
    "code": "М15",
    "url": "https://clck.ru/3WQJQV",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "9642",
        "base": "bt"
      }
    ],
    "externalIds": [
      "9642"
    ]
  },
  {
    "code": "М18",
    "url": "https://clck.ru/3W9ydE",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "9224",
        "base": "bt"
      }
    ],
    "externalIds": [
      "9224"
    ]
  },
  {
    "code": "748 Авито ДБ",
    "url": "https://clck.ru/3UDZEu",
    "partnerId": "748",
    "sourceBases": [
      "bt",
      "kp"
    ],
    "externalRefs": [
      {
        "id": "8321",
        "base": "bt"
      },
      {
        "id": "3601",
        "base": "kp"
      }
    ],
    "externalIds": [
      "8321",
      "3601"
    ]
  },
  {
    "code": "748 Источник №3",
    "url": "https://clck.ru/3WTHy6",
    "partnerId": "748",
    "sourceBases": [
      "bt"
    ],
    "externalRefs": [
      {
        "id": "3270",
        "base": "bt"
      }
    ],
    "externalIds": [
      "3270"
    ]
  }
];
  const api = Object.freeze({revision:'owner-approved-2026-10-22-41',entries:Object.freeze(entries.map(entry => Object.freeze({...entry,externalIds:Object.freeze(entry.externalIds),sourceBases:Object.freeze(entry.sourceBases),externalRefs:Object.freeze(entry.externalRefs.map(value => Object.freeze(value)))})))});
  globalThis.CRMAvitoOwnerSources = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})();
